///<reference types="Cypress" />

describe("Test Contact Us form via WebDriverUniversity", () => {
    it("Should be able to open contact us form", () => {
        cy.visit("http://www.webdriveruniversity.com");
        cy.get('#contact-us').click({force: true});
    });  
    
    it("Should be able to submit a succesful submission via contact us form", () => {
        cy.visit("http://www.webdriveruniversity.com/Contact-Us/contactus.html");
        cy.get('[name="first_name"]').type("James");
        cy.get('[name="last_name"]').type("Bond");
        cy.get('[name="email"]').type("jb@jb.com");
        cy.get('textarea.feedback-input').type("qwe eqwjeoqwejioqwe jqowejoiqwjeoiqwje");
        cy.get('[type="submit"]').click();
    });  

    it("Should not be able to submit a succesful submission via contact us form as all fields required", () => {
        cy.visit("http://www.webdriveruniversity.com/Contact-Us/contactus.html");
        cy.get('[name="first_name"]').type("Andzej");
        cy.get('[name="last_name"]').type("Bond");
        cy.get('textarea.feedback-input').type("qwe eqwjeoqwejioqwe jqowejoiqwjeoiqwje");
        cy.get('[type="submit"]').click();
    }); 


})