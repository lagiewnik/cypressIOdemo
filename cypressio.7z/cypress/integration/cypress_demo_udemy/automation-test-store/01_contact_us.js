///<reference types="Cypress" />

describe("Test Contact Us form via Automation Test Store", () => {
    it("Should be able to open contact us form", () => {
        cy.visit("https://automationteststore.com/");
        //cy.get('.info_links_footer > :nth-child(5) > a').click();

        cy.xpath("//a[contains(text(),'Contact Us')]").click();
        cy.get('#ContactUsFrm_first_name').type("Marianna");
        cy.get('#ContactUsFrm_email').type("Marianna@ep.pl");
        cy.get('#ContactUsFrm_enquiry').type("Marianna asdasd asd adf f afd asdf");
        cy.get("button[title='Submit']").click();
    });  
    

})